#!/bin/bash
exec 1>info_eth.txt

USRS() {
	len=$(cat /etc/passwd | wc -l | bc)
	i=1
	while [[ "$i" -lt "$len" ]]
	do
		sentence=$(sed "${i}q;d" /etc/passwd | cut -d: -f7)
		adder=$(sed "${i}q;d" /etc/passwd | cut -d: -f1)
		if [[ $sentence == "/bin/bash" || $sentence == "/bin/sh" ]]; then
			usrs+=$adder" "
		fi
		>/dev/null echo -e -e -n "$[i+=1]"
	done
}

netaddr_calc() {
	if [[ "$1" != "" && "$2" != "" ]]; then
		ip1=$(echo -e -e $1 | cut -d. -f1)
		ip2=$(echo -e -e $1 | cut -d. -f2)
		ip3=$(echo -e -e $1 | cut -d. -f3)
		ip4=$(echo -e -e $1 | cut -d. -f4)

		nm1=$(echo -e -e $2 | cut -d. -f1)
		nm2=$(echo -e -e $2 | cut -d. -f2)
		nm3=$(echo -e -e $2 | cut -d. -f3)
		nm4=$(echo -e -e $2 | cut -d. -f4)

		netaddr=$(($nm1&$ip1)).$(($nm2&$ip2)).$(($nm3&$ip3)).$(($nm4&$ip4))
	else
		echo -e "		ATENCIO! IP o Mascara no valides"
	fi
}
if [[ $EUID -ne 0 ]]; then
   echo -e "Script disponible nomes amb permis de root" 1>&2
   exit 1
fi

USRS
date=$(date)
hostname=$(hostname)
routerip=$(netstat -r | grep default | cut -d' ' -f 10)
extip=$(wget http://ipinfo.io/ip -qO -)
dns1=$(cat /etc/resolv.conf | grep nameserver | head -1 | cut -d' ' -f2)
dns2=$(cat /etc/resolv.conf | grep nameserver | tail -1 | cut -d' ' -f2)
var=$(ifconfig | grep encap | cut -d' ' -f1)

echo -e "========================================================================="
echo -e "|         NetStat and NetInfo Script By: Jordi Mestres. SEAX		|"
echo -e "========================================================================="
echo -e "	Dades de l'equip"
echo -e
echo -e "	Data:				"$date
echo -e "	Usuaris Humans:		 	"${usrs}
echo -e "	Hostname:			"$hostname
echo -e "	Addr IP del router:		"$routerip
echo -e "	Addr IP externa:		"$extip
echo -e "	Addr IP DNS primari:		"$dns1
echo -e "	Addr IP DNS secundari:		"$dns2

for iface in $var
	do
		echo -e
		echo -e "	Interficie: " $iface
		echo -e "		Addr MAC:		" `cat /sys/class/net/$iface/address`
		if [[ `cat /sys/class/net/$iface/operstate` == "up" ]]; then
			echo -e "		INTERFICIE ACTIVA "
			ip=$(ifconfig $iface | grep 'inet addr:' |cut -d: -f2 |cut -d' ' -f1)
			if [[ "$1" != "" ]]; then
				dnss=$(dig -x $ip +short)
			else
				dnss=""
			fi
			netmask=$(ifconfig $iface | grep 'Mask:' |cut -d: -f4 |cut -d' ' -f1)
			bcast=$(ifconfig $iface | grep 'Bcast:' |cut -d: -f3 |cut -d' ' -f1)
			netaddr_calc $ip $netmask
			name=$(cat /etc/networks | grep $netaddr | cut -d$'\t' -f1)
			MTU=$(ifconfig $iface | grep 'MTU:' |cut -d: -f2 |cut -d' ' -f1)

			echo -e "		Addr IP:		" $ip
			echo -e "		Nom DNS:		" $dnss
			echo -e "		Mascara de xarxa:	" $netmask
			echo -e "		Addr de xarxa:		" $netaddr
			echo -e "		Nom de la xarxa:	" $name
			echo -e "		MTU:			" $MTU
			echo -e
		else
			echo -e "		INTERFICIE INACTIVA "
		fi
	done
echo -e "========================================================================="
