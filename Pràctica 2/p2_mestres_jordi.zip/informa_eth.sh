#!/bin/bash
USRS() {
	len=$(cat /etc/passwd | wc -l | bc)
	i=1
	while [[ "$i" -lt "$len" ]]
	do
		sentence=$(sed "${i}q;d" /etc/passwd | cut -d: -f7)
		adder=$(sed "${i}q;d" /etc/passwd | cut -d: -f1)
		if [[ $sentence == "/bin/bash" || $sentence == "/bin/sh" ]]; then
			usrs+=$adder" "
		fi
		>/dev/null echo -n "$[i+=1]"
	done
}

netaddr_calc() {
	ip1=$(echo $1 | cut -d. -f1)
	ip2=$(echo $1 | cut -d. -f2)
	ip3=$(echo $1 | cut -d. -f3)
	ip4=$(echo $1 | cut -d. -f4)

	nm1=$(echo $2 | cut -d. -f1)
	nm2=$(echo $2 | cut -d. -f2)
	nm3=$(echo $2 | cut -d. -f3)
	nm4=$(echo $2 | cut -d. -f4)

	netaddr=$(($nm1&$ip1)).$(($nm2&$ip2)).$(($nm3&$ip3)).$(($nm4&$ip4))
}

USRS
echo " ========================================================================" > info_eth.txt
echo "|         NetStat and NetInfo Script By: Jordi Mestres. SEAX		 |" >> info_eth.txt
echo " ========================================================================" >> info_eth.txt
echo "Dades de l'equip" >> info_eth.txt
echo >> info_eth.txt
echo "	Data:			" `date` >> info_eth.txt
echo "	Usuaris Humans:		 ${usrs}" >> info_eth.txt
echo "	Hostname:		" `hostname` >> info_eth.txt
echo "	Addr IP del router:	" `netstat -r | grep default | cut -d' ' -f 10` >> info_eth.txt
echo "	Addr IP externa:	" `wget http://ipinfo.io/ip -qO -` >> info_eth.txt
echo "	Addr IP DNS primari:	" $(sed "1q;d" /etc/resolv.conf | cut -d' ' -f2) >> info_eth.txt
echo "	Addr IP DNS secundari:	" $(sed "2q;d" /etc/resolv.conf | cut -d' ' -f2) >> info_eth.txt
echo >> info_eth.txt

for iface in `ifconfig | grep encap | cut -d' ' -f1`
	do
		echo "	Interficie: " $iface >> info_eth.txt
		echo "		Addr MAC:		" `cat /sys/class/net/$iface/address`  >> info_eth.txt
		if [[ `cat /sys/class/net/$iface/operstate` == "up" ]]; then
			echo "		ONLINE INTERFACE " >> info_eth.txt
			
			ip=$(ifconfig $iface | grep 'inet addr:' |cut -d: -f2 |cut -d' ' -f1)
			dnss=$(cat /etc/resolv.conf | cut -d' ' -f2 | cut -d'D' -f1)
			netmask=$(ifconfig $iface | grep 'Mask:' |cut -d: -f4 |cut -d' ' -f1)
			bcast=$(ifconfig $iface | grep 'Bcast:' |cut -d: -f3 |cut -d' ' -f1)
			netaddr_calc $ip $netmask
			name=$(ifconfig $iface | grep 'Link encap:' |cut -d: -f2 |cut -d' ' -f1)
			MTU=$(ifconfig $iface | grep 'MTU:' |cut -d: -f2 |cut -d' ' -f1)
			
			echo "		Addr IP:		" $ip >> info_eth.txt
			echo "		Nom DNS:		" $dnss >> info_eth.txt
			echo "		Mascara de xarxa:	" $netmask >> info_eth.txt
			echo "		Addr de xarxa:		 "$netaddr  >> info_eth.txt
			echo "		Nom de la xarxa:	" $name >> info_eth.txt
			echo "		MTU:			" $MTU>> info_eth.txt
			echo >> info_eth.txt
		else
			echo "		OFFLINE INTERFACE " >> info_eth.txt
		fi
	done
echo " ========================================================================" >> info_eth.txt

