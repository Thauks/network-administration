#!/bin/bash

iptables-save > /etc/iptables/firewall.rules
