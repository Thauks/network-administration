#!/bin/bash

iptables-restore < /etc/iptables/firewall.rules
